﻿using System;

namespace _01._2NumberPyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int rows = 1;
            int currentNum = 1;
            bool isEqual = false;

            while (isEqual == false)
            {
                for (int i = 1; i <= rows; i++)
                {
                    Console.Write(currentNum + " ");
                    currentNum++;
                    if (currentNum > num)
                    {
                        isEqual = true;
                        break;
                    }
                }
                Console.WriteLine();
                rows++;
            }
        }
    }
}
